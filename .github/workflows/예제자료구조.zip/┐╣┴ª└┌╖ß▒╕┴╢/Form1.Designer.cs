﻿
namespace 예제자료구조
{
    partial class stack
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.queueText5 = new MetroFramework.Controls.MetroLabel();
            this.queueText4 = new MetroFramework.Controls.MetroLabel();
            this.queueText3 = new MetroFramework.Controls.MetroLabel();
            this.queueText2 = new MetroFramework.Controls.MetroLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.stackText1 = new MetroFramework.Controls.MetroLabel();
            this.stackText2 = new MetroFramework.Controls.MetroLabel();
            this.stackText3 = new MetroFramework.Controls.MetroLabel();
            this.stackText4 = new MetroFramework.Controls.MetroLabel();
            this.stackText5 = new MetroFramework.Controls.MetroLabel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.metroButton5 = new MetroFramework.Controls.MetroButton();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.queueText1 = new MetroFramework.Controls.MetroLabel();
            this.queueClearButton = new MetroFramework.Controls.MetroButton();
            this.stackClearButton = new MetroFramework.Controls.MetroButton();
            this.sendQueue = new MetroFramework.Controls.MetroButton();
            this.sendStack = new MetroFramework.Controls.MetroButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.queueText1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.queueText5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.queueText4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.queueText3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.queueText2, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(201, 158);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(508, 100);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // queueText5
            // 
            this.queueText5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.queueText5.AutoSize = true;
            this.queueText5.Location = new System.Drawing.Point(432, 40);
            this.queueText5.Name = "queueText5";
            this.queueText5.Size = new System.Drawing.Size(47, 20);
            this.queueText5.TabIndex = 4;
            this.queueText5.Text = "큐5번";
            // 
            // queueText4
            // 
            this.queueText4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.queueText4.AutoSize = true;
            this.queueText4.Location = new System.Drawing.Point(330, 40);
            this.queueText4.Name = "queueText4";
            this.queueText4.Size = new System.Drawing.Size(47, 20);
            this.queueText4.TabIndex = 3;
            this.queueText4.Text = "큐4번";
            // 
            // queueText3
            // 
            this.queueText3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.queueText3.AutoSize = true;
            this.queueText3.Location = new System.Drawing.Point(229, 40);
            this.queueText3.Name = "queueText3";
            this.queueText3.Size = new System.Drawing.Size(47, 20);
            this.queueText3.TabIndex = 2;
            this.queueText3.Text = "큐3번";
            // 
            // queueText2
            // 
            this.queueText2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.queueText2.AutoSize = true;
            this.queueText2.Location = new System.Drawing.Point(128, 40);
            this.queueText2.Name = "queueText2";
            this.queueText2.Size = new System.Drawing.Size(47, 20);
            this.queueText2.TabIndex = 1;
            this.queueText2.Text = "큐2번";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.stackText1, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.stackText2, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.stackText3, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.stackText4, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.stackText5, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(273, 340);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(351, 262);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // stackText1
            // 
            this.stackText1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.stackText1.AutoSize = true;
            this.stackText1.Location = new System.Drawing.Point(146, 225);
            this.stackText1.Name = "stackText1";
            this.stackText1.Size = new System.Drawing.Size(59, 20);
            this.stackText1.TabIndex = 4;
            this.stackText1.Text = "스택1번";
            // 
            // stackText2
            // 
            this.stackText2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.stackText2.AutoSize = true;
            this.stackText2.Location = new System.Drawing.Point(144, 172);
            this.stackText2.Name = "stackText2";
            this.stackText2.Size = new System.Drawing.Size(62, 20);
            this.stackText2.TabIndex = 3;
            this.stackText2.Text = "스택2번";
            // 
            // stackText3
            // 
            this.stackText3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.stackText3.AutoSize = true;
            this.stackText3.Location = new System.Drawing.Point(144, 120);
            this.stackText3.Name = "stackText3";
            this.stackText3.Size = new System.Drawing.Size(62, 20);
            this.stackText3.TabIndex = 2;
            this.stackText3.Text = "스택3번";
            // 
            // stackText4
            // 
            this.stackText4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.stackText4.AutoSize = true;
            this.stackText4.Location = new System.Drawing.Point(144, 68);
            this.stackText4.Name = "stackText4";
            this.stackText4.Size = new System.Drawing.Size(62, 20);
            this.stackText4.TabIndex = 1;
            this.stackText4.Text = "스택4번";
            // 
            // stackText5
            // 
            this.stackText5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.stackText5.AutoSize = true;
            this.stackText5.Location = new System.Drawing.Point(144, 16);
            this.stackText5.Name = "stackText5";
            this.stackText5.Size = new System.Drawing.Size(62, 20);
            this.stackText5.TabIndex = 0;
            this.stackText5.Text = "스택5번";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.metroButton5, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.metroButton4, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.metroButton3, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.metroButton2, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.metroButton1, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(201, 63);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(508, 42);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // metroButton5
            // 
            this.metroButton5.Location = new System.Drawing.Point(407, 3);
            this.metroButton5.Name = "metroButton5";
            this.metroButton5.Size = new System.Drawing.Size(95, 34);
            this.metroButton5.TabIndex = 4;
            this.metroButton5.Text = "김";
            this.metroButton5.UseSelectable = true;
            this.metroButton5.Click += new System.EventHandler(this.metroButton5_Click);
            // 
            // metroButton4
            // 
            this.metroButton4.Location = new System.Drawing.Point(306, 3);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(95, 34);
            this.metroButton4.TabIndex = 3;
            this.metroButton4.Text = "밥";
            this.metroButton4.UseSelectable = true;
            this.metroButton4.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // metroButton3
            // 
            this.metroButton3.Location = new System.Drawing.Point(205, 3);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(95, 34);
            this.metroButton3.TabIndex = 2;
            this.metroButton3.Text = "햄";
            this.metroButton3.UseSelectable = true;
            this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(104, 3);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(95, 34);
            this.metroButton2.TabIndex = 1;
            this.metroButton2.Text = "맛살";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(3, 3);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(95, 34);
            this.metroButton1.TabIndex = 0;
            this.metroButton1.Text = "당근";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // queueText1
            // 
            this.queueText1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.queueText1.AutoSize = true;
            this.queueText1.Location = new System.Drawing.Point(28, 40);
            this.queueText1.Name = "queueText1";
            this.queueText1.Size = new System.Drawing.Size(44, 20);
            this.queueText1.TabIndex = 5;
            this.queueText1.Text = "큐1번";
            // 
            // queueClearButton
            // 
            this.queueClearButton.Location = new System.Drawing.Point(67, 184);
            this.queueClearButton.Name = "queueClearButton";
            this.queueClearButton.Size = new System.Drawing.Size(93, 43);
            this.queueClearButton.TabIndex = 3;
            this.queueClearButton.Text = "큐 클리어";
            this.queueClearButton.UseSelectable = true;
            this.queueClearButton.Click += new System.EventHandler(this.queueClearButton_Click);
            // 
            // stackClearButton
            // 
            this.stackClearButton.Location = new System.Drawing.Point(67, 437);
            this.stackClearButton.Name = "stackClearButton";
            this.stackClearButton.Size = new System.Drawing.Size(93, 43);
            this.stackClearButton.TabIndex = 4;
            this.stackClearButton.Text = "스택 클리어";
            this.stackClearButton.UseSelectable = true;
            this.stackClearButton.Click += new System.EventHandler(this.stackClearButton_Click);
            // 
            // sendQueue
            // 
            this.sendQueue.Location = new System.Drawing.Point(244, 281);
            this.sendQueue.Name = "sendQueue";
            this.sendQueue.Size = new System.Drawing.Size(96, 37);
            this.sendQueue.TabIndex = 5;
            this.sendQueue.Text = "큐로 보내기 ↑";
            this.sendQueue.UseSelectable = true;
            this.sendQueue.Click += new System.EventHandler(this.sendQueue_Click);
            // 
            // sendStack
            // 
            this.sendStack.Location = new System.Drawing.Point(548, 281);
            this.sendStack.Name = "sendStack";
            this.sendStack.Size = new System.Drawing.Size(132, 37);
            this.sendStack.TabIndex = 6;
            this.sendStack.Text = "스택으로 보내기 ↓";
            this.sendStack.UseSelectable = true;
            this.sendStack.Click += new System.EventHandler(this.sendStack_Click);
            // 
            // stack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 693);
            this.Controls.Add(this.sendStack);
            this.Controls.Add(this.sendQueue);
            this.Controls.Add(this.stackClearButton);
            this.Controls.Add(this.queueClearButton);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "stack";
            this.Text = "stack, queue 예제";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private MetroFramework.Controls.MetroLabel queueText5;
        private MetroFramework.Controls.MetroLabel queueText4;
        private MetroFramework.Controls.MetroLabel queueText3;
        private MetroFramework.Controls.MetroLabel queueText2;
        private MetroFramework.Controls.MetroLabel stackText1;
        private MetroFramework.Controls.MetroLabel stackText2;
        private MetroFramework.Controls.MetroLabel stackText3;
        private MetroFramework.Controls.MetroLabel stackText4;
        private MetroFramework.Controls.MetroLabel stackText5;
        private MetroFramework.Controls.MetroButton metroButton5;
        private MetroFramework.Controls.MetroButton metroButton4;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroLabel queueText1;
        private MetroFramework.Controls.MetroButton queueClearButton;
        private MetroFramework.Controls.MetroButton stackClearButton;
        private MetroFramework.Controls.MetroButton sendQueue;
        private MetroFramework.Controls.MetroButton sendStack;
    }
}

