﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 예제자료구조
{
    public partial class stack : MetroFramework.Forms.MetroForm
    {

        public stack()
        {
            InitializeComponent();
        }
        static public Queue<string> queueCollection = new Queue<string>();
        static public Stack<string> stackCollection = new Stack<string>();
        static public string[] queueCopy = new string[5];
        static public string[] stackCopy = new string[5];

        

        public void queueTextChange()
        {
            if (queueCollection.Count==0)
            {
                queueText1.Text = "큐1번";
                queueText2.Text = "큐2번";
                queueText3.Text = "큐3번";
                queueText4.Text = "큐4번";
                queueText5.Text = "큐5번";
            }

            if (queueCollection.Count == 1)
            {
                queueText1.Text = queueCollection.Peek();
                queueText2.Text = "큐2번";
                queueText3.Text = "큐3번";
                queueText4.Text = "큐4번";
                queueText5.Text = "큐5번";
            }
            if (queueCollection.Count == 2)
            {
                queueText1.Text = queueCopy[1];
                queueText2.Text = queueCollection.Peek();
                queueText3.Text = "큐3번";
                queueText4.Text = "큐4번";
                queueText5.Text = "큐5번";
            }
            if (queueCollection.Count == 3)
            {
                queueText1.Text = queueCopy[2];
                queueText2.Text = queueCopy[1];
                queueText3.Text = queueCollection.Peek();
                queueText4.Text = "큐4번";
                queueText5.Text = "큐5번";
            }
            if (queueCollection.Count == 4)
            {
                queueText1.Text = queueCopy[3];
                queueText2.Text = queueCopy[2];
                queueText3.Text = queueCopy[1];
                queueText4.Text = queueCollection.Peek();
                queueText5.Text = "큐5번";
            }
            if (queueCollection.Count == 5)
            {
                queueText1.Text = queueCopy[4];
                queueText2.Text = queueCopy[3];
                queueText3.Text = queueCopy[2];
                queueText4.Text = queueCopy[1];
                queueText5.Text = queueCollection.Peek();
            }
        }
        public void stackTextChange()
        {
            if (stackCollection.Count == 0)
            {
                stackText1.Text = "스택1번";
                stackText2.Text = "스택2번";
                stackText3.Text = "스택3번";
                stackText4.Text = "스택4번";
                stackText5.Text = "스택5번";
            }

            if (stackCollection.Count == 1)
            {
                stackText1.Text = stackCollection.Peek();
                stackText2.Text = "스택2번";
                stackText3.Text = "스택3번";
                stackText4.Text = "스택4번";
                stackText5.Text = "스택5번";
            }
            if (stackCollection.Count == 2)
            {
                stackText1.Text = stackCopy[1];
                stackText2.Text = stackCollection.Peek();
                stackText3.Text = "스택3번";
                stackText4.Text = "스택4번";
                stackText5.Text = "스택5번";
            }
            if (stackCollection.Count == 3)
            {
                stackText1.Text = stackCopy[2];
                stackText2.Text = stackCopy[1];
                stackText3.Text = stackCollection.Peek();
                stackText4.Text = "스택4번";
                stackText5.Text = "스택5번";
            }
            if (stackCollection.Count == 4)
            {
                stackText1.Text = stackCopy[3];
                stackText2.Text = stackCopy[2];
                stackText3.Text = stackCopy[1];
                stackText4.Text = stackCollection.Peek();
                stackText5.Text = "스택5번";
            }
            if (stackCollection.Count == 5)
            {
                stackText1.Text = stackCopy[4];
                stackText2.Text = stackCopy[3];
                stackText3.Text = stackCopy[2];
                stackText4.Text = stackCopy[1];
                stackText5.Text = stackCollection.Peek();
            }
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            if (queueCollection.Count!=5)
            {
                queueCollection.Enqueue("당근");
            }
            queueCopy = queueCollection.ToArray();
            queueTextChange();
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            if (queueCollection.Count != 5)
            {
                queueCollection.Enqueue("맛살");
            }
            queueCopy = queueCollection.ToArray();
            queueTextChange();
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            if (queueCollection.Count != 5)
            {
                queueCollection.Enqueue("햄");
            }
            queueCopy = queueCollection.ToArray();
            queueTextChange();
        }

        private void metroButton4_Click(object sender, EventArgs e)
        {
            if (queueCollection.Count != 5)
            {
                queueCollection.Enqueue("밥");
            }
            queueCopy = queueCollection.ToArray();
            queueTextChange();
        }

        private void metroButton5_Click(object sender, EventArgs e)
        {
            if (queueCollection.Count != 5)
            {
                queueCollection.Enqueue("김");
            }
            queueCopy = queueCollection.ToArray();
            queueTextChange();
        }

        private void queueClearButton_Click(object sender, EventArgs e)
        {
            queueCollection.Clear();
            queueCopy = queueCollection.ToArray();
            queueTextChange();
        }

        private void sendStack_Click(object sender, EventArgs e)
        {
            if (queueCollection.Count!=0)
            {
                stackCollection.Push(queueCollection.Dequeue());
                stackCopy = stackCollection.ToArray();
                queueCopy = queueCollection.ToArray();
                queueTextChange();
                stackTextChange();
            }


        }

        private void sendQueue_Click(object sender, EventArgs e)
        {
            if (stackCollection.Count != 0)
            {
                queueCollection.Enqueue(stackCollection.Pop());
                stackCopy = stackCollection.ToArray();
                queueCopy = queueCollection.ToArray();
                queueTextChange();
                stackTextChange();
            }
        }

        private void stackClearButton_Click(object sender, EventArgs e)
        {
            stackCollection.Clear();
            stackCopy = stackCollection.ToArray();
            stackTextChange();
        }
    }
}
